"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'favoriteDashboards';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'FavoriteDashboards';
exports.PLUGIN_NAME = PLUGIN_NAME;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQTFVHSU5fSUQiLCJQTFVHSU5fTkFNRSJdLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBQTFVHSU5fSUQgPSAnZmF2b3JpdGVEYXNoYm9hcmRzJztcbmV4cG9ydCBjb25zdCBQTFVHSU5fTkFNRSA9ICdGYXZvcml0ZURhc2hib2FyZHMnO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBTyxNQUFNQSxTQUFTLEdBQUcsb0JBQWxCOztBQUNBLE1BQU1DLFdBQVcsR0FBRyxvQkFBcEIifQ==